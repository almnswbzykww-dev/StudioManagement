using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Input;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Win32;
using StudioManagement.Application.DTOs;
using StudioManagement.Application.Interfaces;
using StudioManagement.Domain.Enums;
using StudioManagement.Infrastructure.Data;

namespace StudioManagement.WPF.ViewModels;

public partial class MainViewModel : ObservableObject
{
    private readonly IServiceProvider _serviceProvider;
    private readonly ICurrentUserService _currentUser;
    private readonly IStudioSettingsService _settings;

    [ObservableProperty] private object? _currentViewModel;
    [ObservableProperty] private string _studioName = "استديو الفن 3";
    [ObservableProperty] private string _currentUserRoleName = "المهندس زكريا فيصل العزعزي";
    [ObservableProperty] private string _currentTimeFormatted = DateTime.Now.ToString("hh:mm:ss tt", System.Globalization.CultureInfo.InvariantCulture);
    [ObservableProperty] private string _currentDateFormatted = DateTime.Now.ToString("dddd, dd MMMM yyyy", System.Globalization.CultureInfo.InvariantCulture);
    [ObservableProperty] private bool _isSidebarExpanded = true;

    private readonly System.Windows.Threading.DispatcherTimer? _clockTimer;

    public MainViewModel(IServiceProvider serviceProvider, ICurrentUserService currentUser, IStudioSettingsService settings)
    {
        _serviceProvider = serviceProvider;
        _currentUser = currentUser;
        _settings = settings;

        // Update English Date, Time, and Day every second
        _clockTimer = new System.Windows.Threading.DispatcherTimer
        {
            Interval = TimeSpan.FromSeconds(1)
        };
        _clockTimer.Tick += (s, e) =>
        {
            CurrentTimeFormatted = DateTime.Now.ToString("hh:mm:ss tt", System.Globalization.CultureInfo.InvariantCulture);
            CurrentDateFormatted = DateTime.Now.ToString("dddd, dd MMMM yyyy", System.Globalization.CultureInfo.InvariantCulture);
        };
        _clockTimer.Start();

        _settings.SettingsChanged += (s, e) =>
        {
            Application.Current?.Dispatcher?.Invoke(() =>
            {
                StudioName = e.StudioName;
                if (_currentUser.CurrentUser != null)
                {
                    if (_currentUser.CurrentUser.RoleName == "مدير النظام")
                        CurrentUserRoleName = $"{e.SystemManagerName} (مدير النظام)";
                    else
                        CurrentUserRoleName = $"{_currentUser.CurrentUser.FullName} ({_currentUser.CurrentUser.RoleName})";
                }
            });
        };

        Task.Run(async () =>
        {
            try
            {
                var st = await _settings.GetSettingsAsync();
                Application.Current?.Dispatcher?.Invoke(() =>
                {
                    StudioName = st.StudioName;
                    if (_currentUser.CurrentUser != null)
                    {
                        if (_currentUser.CurrentUser.RoleName == "مدير النظام")
                            CurrentUserRoleName = $"{st.SystemManagerName} (مدير النظام)";
                        else
                            CurrentUserRoleName = $"{_currentUser.CurrentUser.FullName} ({_currentUser.CurrentUser.RoleName})";
                    }
                });
            }
            catch { }
        });

        GoToDashboardCommand.Execute(null);
    }

    [RelayCommand]
    private void MinimizeWindow(Window? win)
    {
        if (win != null)
        {
            win.WindowState = WindowState.Minimized;
        }
        else if (Application.Current?.MainWindow != null)
        {
            Application.Current.MainWindow.WindowState = WindowState.Minimized;
        }
    }

    [RelayCommand]
    private void MaximizeWindow(Window? win)
    {
        var target = win ?? Application.Current?.MainWindow;
        if (target != null)
        {
            target.WindowState = target.WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        }
    }

    [RelayCommand]
    private void CloseWindow(Window? win)
    {
        Logout();
    }

    [RelayCommand]
    private void ToggleSidebar() => IsSidebarExpanded = !IsSidebarExpanded;

    [RelayCommand]
    private void GoToDashboard() => CurrentViewModel = (DashboardViewModel)_serviceProvider.GetService(typeof(DashboardViewModel))!;

    [RelayCommand]
    private void GoToCustomers()
    {
        if (!_currentUser.HasPermission("Customers:View"))
        {
            ShowPermissionWarning("مشاهدة العملاء");
            return;
        }
        CurrentViewModel = (CustomersViewModel)_serviceProvider.GetService(typeof(CustomersViewModel))!;
    }

    [RelayCommand]
    private void GoToOrders()
    {
        if (!_currentUser.HasPermission("Orders:View"))
        {
            ShowPermissionWarning("مشاهدة الطلبات والفواتير");
            return;
        }
        CurrentViewModel = (OrdersViewModel)_serviceProvider.GetService(typeof(OrdersViewModel))!;
    }

    [RelayCommand]
    private void GoToInventory()
    {
        if (!_currentUser.HasPermission("Orders:View"))
        {
            ShowPermissionWarning("المخزون والخامات");
            return;
        }
        CurrentViewModel = (InventoryViewModel)_serviceProvider.GetService(typeof(InventoryViewModel))!;
    }

    [RelayCommand]
    private void GoToSuppliers()
    {
        if (!_currentUser.HasPermission("Accounting:View"))
        {
            ShowPermissionWarning("الموردون والمشتريات");
            return;
        }
        CurrentViewModel = (SuppliersViewModel)_serviceProvider.GetService(typeof(SuppliersViewModel))!;
    }

    [RelayCommand]
    private void GoToAccounting()
    {
        if (!_currentUser.HasPermission("Accounting:View"))
        {
            ShowPermissionWarning("المحاسبة والصندوق");
            return;
        }
        CurrentViewModel = (AccountingViewModel)_serviceProvider.GetService(typeof(AccountingViewModel))!;
    }

    [RelayCommand]
    private void GoToReports()
    {
        if (!_currentUser.HasPermission("Reports:Sales") && !_currentUser.HasPermission("Reports:TodayIncome") && !_currentUser.HasPermission("Reports:FullFinancial"))
        {
            ShowPermissionWarning("التقارير المالية");
            return;
        }
        CurrentViewModel = (ReportsViewModel)_serviceProvider.GetService(typeof(ReportsViewModel))!;
    }

    [RelayCommand]
    private void GoToSettings()
    {
        if (!_currentUser.HasPermission("Settings:System") && !_currentUser.HasPermission("Settings:StudioInfo") && !_currentUser.HasPermission("Settings:Users"))
        {
            ShowPermissionWarning("إعدادات الاستديو والمستخدمين");
            return;
        }
        CurrentViewModel = (SettingsViewModel)_serviceProvider.GetService(typeof(SettingsViewModel))!;
    }

    private static void ShowPermissionWarning(string moduleName)
    {
        MessageBox.Show(
            $"عذراً، ليس لديك صلاحية للوصول إلى [{moduleName}]. يرجى مراجعة مدير النظام.",
            "صلاحية غير كافية",
            MessageBoxButton.OK,
            MessageBoxImage.Warning,
            MessageBoxResult.OK,
            MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading
        );
    }

    [RelayCommand]
    private void Logout()
    {
        var result = MessageBox.Show(
            "هل تريد تسجيل الخروج؟",
            "تسجيل الخروج من النظام",
            MessageBoxButton.YesNo,
            MessageBoxImage.Question,
            MessageBoxResult.No,
            MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading
        );

        if (result != MessageBoxResult.Yes) return;

        _currentUser.CurrentUser = null;
        var loginWin = (Views.LoginWindow)_serviceProvider.GetService(typeof(Views.LoginWindow))!;
        loginWin.Show();
        Application.Current.MainWindow.Close();
        Application.Current.MainWindow = loginWin;
    }
}

public partial class LoginViewModel : ObservableObject
{
    private readonly IAuthService _auth;
    private readonly ICurrentUserService _currentUser;
    private readonly IStudioSettingsService _settingsService;
    private readonly IServiceProvider _sp;

    [ObservableProperty] private string _userNumber = "1001";
    [ObservableProperty] private string _username = "admin";
    [ObservableProperty] private string _detectedUserName = string.Empty;
    [ObservableProperty] private string _detectedRoleTitle = string.Empty;
    [ObservableProperty] private bool _isUserDetected;
    [ObservableProperty] private string _password = string.Empty;
    [ObservableProperty] private string _errorMessage = string.Empty;
    [ObservableProperty] private bool _isLoading;
    [ObservableProperty] private string _studioName = "استديو الفن 3";
    [ObservableProperty] private string _studioTagline = "لتصوير الفيديو والإعلانات والطباعة الرقمية والحرارية";
    [ObservableProperty] private string? _studioLogoBase64;
    [ObservableProperty] private ObservableCollection<UserDto> _availableUsers = new();

    public LoginViewModel(IAuthService auth, ICurrentUserService currentUser, IStudioSettingsService settingsService, IServiceProvider sp)
    {
        _auth = auth;
        _currentUser = currentUser;
        _settingsService = settingsService;
        _sp = sp;

        Task.Run(async () =>
        {
            try
            {
                var s = await _settingsService.GetSettingsAsync();
                var users = await _auth.GetActiveUsersForLoginAsync();
                Application.Current?.Dispatcher?.Invoke(() =>
                {
                    StudioName = s.StudioName;
                    StudioTagline = s.Tagline;
                    StudioLogoBase64 = s.LogoBase64;
                    AvailableUsers = new ObservableCollection<UserDto>(users);
                    SearchUserCommand.Execute(null);
                });
            }
            catch { }
        });
    }

    [RelayCommand]
    private async Task SearchUserAsync()
    {
        if (string.IsNullOrWhiteSpace(UserNumber))
        {
            DetectedUserName = string.Empty;
            DetectedRoleTitle = string.Empty;
            IsUserDetected = false;
            return;
        }

        var user = await _auth.FindUserByNumberOrUsernameAsync(UserNumber);
        if (user != null)
        {
            Username = user.Username;
            DetectedUserName = user.FullName;
            DetectedRoleTitle = user.RoleName;
            IsUserDetected = true;
            ErrorMessage = string.Empty;
        }
        else
        {
            DetectedUserName = string.Empty;
            DetectedRoleTitle = string.Empty;
            IsUserDetected = false;
        }
    }

    partial void OnUserNumberChanged(string value)
    {
        SearchUserCommand.Execute(null);
    }

    [RelayCommand]
    private void SelectUserChip(UserDto user)
    {
        UserNumber = user.UserNumber.ToString();
        Username = user.Username;
        DetectedUserName = user.FullName;
        DetectedRoleTitle = user.RoleName;
        IsUserDetected = true;
    }

    [RelayCommand]
    private async Task LoginAsync(Window window)
    {
        var targetIdentifier = !string.IsNullOrWhiteSpace(Username) ? Username : UserNumber;
        if (string.IsNullOrWhiteSpace(targetIdentifier))
        {
            ErrorMessage = "يرجى إدخال رقم المستخدم أو اسم المستخدم.";
            return;
        }

        if (string.IsNullOrWhiteSpace(Password))
        {
            ErrorMessage = "يرجى كتابة كلمة المرور للمتابعة.";
            return;
        }

        IsLoading = true;
        ErrorMessage = string.Empty;

        var res = await _auth.LoginAsync(targetIdentifier, Password);
        IsLoading = false;

        if (res.Success && res.User != null)
        {
            _currentUser.CurrentUser = res.User;
            var mainWin = (MainWindow)_sp.GetService(typeof(MainWindow))!;
            mainWin.Show();
            Application.Current.MainWindow = mainWin;
            window.Close();
        }
        else
        {
            ErrorMessage = res.Message;
        }
    }
}

public partial class DashboardViewModel : ObservableObject
{
    private readonly IAccountingService _accounting;
    private readonly IServiceCardService _serviceCards;
    private readonly MainViewModel _mainVm;

    [ObservableProperty] private DashboardStatsDto? _stats;
    [ObservableProperty] private ObservableCollection<ServiceCardDto> _cards = new();

    public DashboardViewModel(IAccountingService accounting, IServiceCardService serviceCards, MainViewModel mainVm)
    {
        _accounting = accounting;
        _serviceCards = serviceCards;
        _mainVm = mainVm;
        LoadDataCommand.Execute(null);
    }

    [RelayCommand]
    private async Task LoadDataAsync()
    {
        Stats = await _accounting.GetDashboardStatsAsync();
        var cardsList = await _serviceCards.GetAllCardsAsync();
        Cards = new ObservableCollection<ServiceCardDto>(cardsList.Where(c => c.IsActive));
    }

    [RelayCommand]
    private void OpenService(ServiceCardDto card)
    {
        _mainVm.GoToOrdersCommand.Execute(null);
    }
}

public partial class CustomersViewModel : ObservableObject
{
    private readonly ICustomerService _customerService;

    [ObservableProperty] private ObservableCollection<CustomerDto> _customers = new();
    [ObservableProperty] private CustomerDto? _selectedCustomer;
    [ObservableProperty] private string _searchQuery = string.Empty;
    [ObservableProperty] private bool _isFormOpen;
    [ObservableProperty] private string _formName = string.Empty;
    [ObservableProperty] private string _formPhone = string.Empty;
    [ObservableProperty] private string _formAddress = string.Empty;
    [ObservableProperty] private string _formNotes = string.Empty;

    public CustomersViewModel(ICustomerService customerService)
    {
        _customerService = customerService;
        SearchCommand.Execute(null);
    }

    [RelayCommand]
    private async Task SearchAsync()
    {
        var list = await _customerService.GetAllAsync(SearchQuery);
        Customers = new ObservableCollection<CustomerDto>(list);
    }

    [RelayCommand]
    private void OpenAdd()
    {
        SelectedCustomer = null;
        FormName = string.Empty;
        FormPhone = string.Empty;
        FormAddress = string.Empty;
        FormNotes = string.Empty;
        IsFormOpen = true;
    }

    [RelayCommand]
    private async Task SaveAsync()
    {
        if (string.IsNullOrWhiteSpace(FormName) || string.IsNullOrWhiteSpace(FormPhone)) return;

        if (SelectedCustomer == null)
        {
            await _customerService.CreateAsync(new CreateCustomerDto(FormName, FormPhone, null, FormAddress, FormNotes));
        }
        else
        {
            await _customerService.UpdateAsync(new UpdateCustomerDto(SelectedCustomer.Id, FormName, FormPhone, null, FormAddress, FormNotes));
        }

        IsFormOpen = false;
        await SearchAsync();
    }

    [RelayCommand]
    private async Task DeleteAsync(CustomerDto customer)
    {
        if (MessageBox.Show($"هل أنت متأكد من حذف العميل {customer.Name}؟", "تأكيد الحذف", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
        {
            await _customerService.DeleteAsync(customer.Id);
            await SearchAsync();
        }
    }
}

public partial class OrdersViewModel : ObservableObject
{
    private readonly IOrderService _orderService;
    private readonly IInvoiceHtmlBuilder _invoiceBuilder;

    [ObservableProperty] private ObservableCollection<OrderDto> _orders = new();
    [ObservableProperty] private OrderDto? _selectedOrder;
    [ObservableProperty] private string _searchQuery = string.Empty;
    [ObservableProperty] private bool _isWizardOpen;

    // Payment overlay
    [ObservableProperty] private bool _isPaymentOpen;
    [ObservableProperty] private decimal _paymentAmount;
    [ObservableProperty] private PaymentMethod _paymentMethod = PaymentMethod.Cash;
    [ObservableProperty] private WalletType _walletType = WalletType.Kuraimi;
    [ObservableProperty] private string _transactionNumber = string.Empty;
    [ObservableProperty] private string _senderName = string.Empty;
    [ObservableProperty] private string _senderPhone = string.Empty;
    [ObservableProperty] private string _paymentNotes = string.Empty;

    public OrdersViewModel(IOrderService orderService, IInvoiceHtmlBuilder invoiceBuilder)
    {
        _orderService = orderService;
        _invoiceBuilder = invoiceBuilder;
        LoadOrdersCommand.Execute(null);
    }

    [RelayCommand]
    private async Task LoadOrdersAsync()
    {
        var list = await _orderService.GetAllAsync(search: SearchQuery);
        Orders = new ObservableCollection<OrderDto>(list);
    }

    [RelayCommand]
    private void OpenNewOrderWizard() => IsWizardOpen = true;

    [RelayCommand]
    private void CloseWizard() => IsWizardOpen = false;

    [RelayCommand]
    private async Task PrintInvoiceAsync(OrderDto order)
    {
        var html = await _invoiceBuilder.BuildInvoiceHtmlAsync(order.Id);
        var tempFile = Path.Combine(Path.GetTempPath(), $"Invoice_{order.OrderNumber}.html");
        await File.WriteAllTextAsync(tempFile, html);
        Process.Start(new ProcessStartInfo(tempFile) { UseShellExecute = true });
    }

    [RelayCommand]
    private void OpenAddPayment(OrderDto order)
    {
        SelectedOrder = order;
        PaymentAmount = order.RemainingAmount;
        PaymentMethod = PaymentMethod.Cash;
        WalletType = WalletType.Kuraimi;
        TransactionNumber = string.Empty;
        SenderName = string.Empty;
        SenderPhone = string.Empty;
        PaymentNotes = string.Empty;
        IsPaymentOpen = true;
    }

    [RelayCommand]
    private void SelectWallet(string walletName)
    {
        PaymentMethod = PaymentMethod.BankWallet;
        switch (walletName)
        {
            case "Jeeb": WalletType = WalletType.Jeeb; break;
            case "Jawwali": WalletType = WalletType.Jawwali; break;
            case "OneCash": WalletType = WalletType.OneCash; break;
            case "Floosak": WalletType = WalletType.Floosak; break;
            case "Kuraimi": WalletType = WalletType.Kuraimi; break;
            default: WalletType = WalletType.BankTransfer; break;
        }
    }

    [RelayCommand]
    private void SelectCash()
    {
        PaymentMethod = PaymentMethod.Cash;
    }

    [RelayCommand]
    private async Task SubmitPaymentAsync()
    {
        if (SelectedOrder == null || PaymentAmount <= 0) return;

        string walletNameStr = PaymentMethod == PaymentMethod.BankWallet ? GetWalletArabicName(WalletType) : null;

        await _orderService.AddPaymentAsync(new CreatePaymentDto(
            SelectedOrder.Id,
            PaymentAmount,
            PaymentMethod,
            PaymentMethod == PaymentMethod.BankWallet ? WalletType : null,
            walletNameStr,
            TransactionNumber,
            TransactionNumber,
            SenderName,
            SenderPhone,
            PaymentNotes
        ));

        IsPaymentOpen = false;
        await LoadOrdersAsync();
    }

    private static string GetWalletArabicName(WalletType w) => w switch
    {
        WalletType.Jeeb => "محفظة جيب",
        WalletType.Jawwali => "محفظة جوالي",
        WalletType.OneCash => "محفظة ون كاش",
        WalletType.Floosak => "محفظة فلوسك",
        WalletType.Kuraimi => "محفظة كريمي / إم فلوس",
        _ => "تحويل بنكي"
    };
}

public partial class OrderWizardViewModel : ObservableObject
{
    private readonly IOrderService _orderService;
    private readonly ICustomerService _customerService;

    [ObservableProperty] private ObservableCollection<CustomerDto> _matchedCustomers = new();
    [ObservableProperty] private CustomerDto? _selectedCustomer;
    [ObservableProperty] private string _customerSearch = string.Empty;

    [ObservableProperty] private ServiceType _selectedService = ServiceType.WeddingBoard;
    [ObservableProperty] private string _itemTitle = "لوحة عرسان ملكية فاخرة مقاس 80×120 سم مع إضاءة LED";
    [ObservableProperty] private decimal _itemPrice = 95000;
    [ObservableProperty] private int _quantity = 1;
    [ObservableProperty] private decimal _discount = 0;
    [ObservableProperty] private decimal _initialPayment = 30000;
    [ObservableProperty] private DateTime _deliveryDate = DateTime.Now.AddDays(7);

    public OrderWizardViewModel(IOrderService orderService, ICustomerService customerService)
    {
        _orderService = orderService;
        _customerService = customerService;
    }

    [RelayCommand]
    private async Task SearchCustomerAsync()
    {
        var list = await _customerService.AutoCompleteAsync(CustomerSearch);
        MatchedCustomers = new ObservableCollection<CustomerDto>(list);
    }
}

public partial class InventoryViewModel : ObservableObject
{
    private readonly IInventoryService _inventory;

    [ObservableProperty] private ObservableCollection<ProductDto> _products = new();
    [ObservableProperty] private ProductDto? _selectedProduct;
    [ObservableProperty] private string _searchQuery = string.Empty;

    public InventoryViewModel(IInventoryService inventory)
    {
        _inventory = inventory;
        LoadProductsCommand.Execute(null);
    }

    [RelayCommand]
    private async Task LoadProductsAsync()
    {
        var list = await _inventory.GetAllProductsAsync(SearchQuery);
        Products = new ObservableCollection<ProductDto>(list);
    }
}

public partial class PurchaseFormViewModel : ObservableObject
{
}

public partial class SuppliersViewModel : ObservableObject
{
    private readonly StudioDbContext _db;
    [ObservableProperty] private ObservableCollection<SupplierDto> _suppliers = new();

    public SuppliersViewModel(StudioDbContext db)
    {
        _db = db;
        LoadSuppliersCommand.Execute(null);
    }

    [RelayCommand]
    private async Task LoadSuppliersAsync()
    {
        // load suppliers
    }
}

public partial class AccountingViewModel : ObservableObject
{
    private readonly IAccountingService _accounting;
    private readonly IExpenseService _expense;
    private readonly IAuthService _auth;

    [ObservableProperty] private decimal _treasuryBalance;
    [ObservableProperty] private ObservableCollection<ExpenseDto> _expenses = new();

    // Today's Income
    [ObservableProperty] private TodayIncomeSummaryDto? _todayIncome;

    // Cashier Income Report
    [ObservableProperty] private CashierIncomeReportDto? _cashierReport;
    [ObservableProperty] private DateTime _filterFromDate = DateTime.Today.AddDays(-7);
    [ObservableProperty] private DateTime _filterToDate = DateTime.Today;
    [ObservableProperty] private string _filterFromTime = "00:00";
    [ObservableProperty] private string _filterToTime = "23:59";
    [ObservableProperty] private ObservableCollection<UserDto> _cashiersList = new();
    [ObservableProperty] private UserDto? _selectedCashier;

    public AccountingViewModel(IAccountingService accounting, IExpenseService expense, IAuthService auth)
    {
        _accounting = accounting;
        _expense = expense;
        _auth = auth;
        LoadDataCommand.Execute(null);
    }

    [RelayCommand]
    private async Task LoadDataAsync()
    {
        TreasuryBalance = await _accounting.GetTreasuryBalanceAsync();
        TodayIncome = await _accounting.GetTodayIncomeSummaryAsync();
        var expList = await _expense.GetAllExpensesAsync();
        Expenses = new ObservableCollection<ExpenseDto>(expList);

        var users = await _auth.GetAllUsersAsync();
        CashiersList = new ObservableCollection<UserDto>(users);

        await SearchCashierIncomeAsync();
    }

    [RelayCommand]
    private async Task SearchCashierIncomeAsync()
    {
        var filter = new CashierIncomeFilterDto(
            FilterFromDate,
            FilterToDate,
            FilterFromTime,
            FilterToTime,
            SelectedCashier?.Id
        );
        CashierReport = await _accounting.GetCashierIncomeReportAsync(filter);
    }
}

public partial class ReportsViewModel : ObservableObject
{
    private readonly IReportHtmlBuilder _reportBuilder;

    [ObservableProperty] private DateTime _fromDate = DateTime.Now.AddDays(-30);
    [ObservableProperty] private DateTime _toDate = DateTime.Now;

    public ReportsViewModel(IReportHtmlBuilder reportBuilder)
    {
        _reportBuilder = reportBuilder;
    }

    [RelayCommand]
    private async Task OpenSalesReportAsync()
    {
        var html = await _reportBuilder.BuildSalesReportHtmlAsync(FromDate, ToDate);
        OpenHtml(html);
    }

    [RelayCommand]
    private async Task OpenProfitLossReportAsync()
    {
        var html = await _reportBuilder.BuildProfitLossHtmlAsync(FromDate, ToDate);
        OpenHtml(html);
    }

    [RelayCommand]
    private async Task OpenDebtsReportAsync()
    {
        var html = await _reportBuilder.BuildCustomerDebtsHtmlAsync();
        OpenHtml(html);
    }

    [RelayCommand]
    private async Task OpenInventoryReportAsync()
    {
        var html = await _reportBuilder.BuildInventoryReportHtmlAsync();
        OpenHtml(html);
    }

    private static void OpenHtml(string html)
    {
        var file = Path.Combine(Path.GetTempPath(), $"Report_{DateTime.Now:yyyyMMdd_HHmmss}.html");
        File.WriteAllText(file, html);
        Process.Start(new ProcessStartInfo(file) { UseShellExecute = true });
    }
}

public partial class PermissionCheckItem : ObservableObject
{
    public string Key { get; set; } = string.Empty;
    public string Module { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    [ObservableProperty] private bool _isSelected;
}

public partial class SettingsViewModel : ObservableObject
{
    private readonly IStudioSettingsService _settingsService;
    private readonly IBackupService _backupService;
    private readonly IAuthService _auth;
    private readonly ICurrentUserService _currentUser;

    // Sub-Tabs
    [ObservableProperty] private int _selectedTab = 0; // 0=StudioInfo, 1=SystemData, 2=Users&Permissions, 3=Password, 4=Backup

    // Studio Info Properties (Dynamic & Centralized)
    [ObservableProperty] private string _studioName = "استديو الفن 3";
    [ObservableProperty] private string _systemManagerName = "المهندس زكريا فيصل العزعزي";
    [ObservableProperty] private string _tagline = "لتصوير الفيديو والإعلانات والطباعة الرقمية والحرارية";
    [ObservableProperty] private string _address = "صنعاء - حدة - جولة الرويشان";
    [ObservableProperty] private string _phone = "01-445566";
    [ObservableProperty] private string _secondaryPhone = "777111222";
    [ObservableProperty] private string _whatsapp = "777000111";
    [ObservableProperty] private string _email = "info@artstudio3.ye";
    [ObservableProperty] private string _description = "استديو تصوير سينمائي ومونتاج إعلانات وطباعة حرارية فاخرة";
    [ObservableProperty] private string _currency = "ر.ي";
    [ObservableProperty] private string? _logoPath;
    [ObservableProperty] private string? _logoBase64;
    [ObservableProperty] private string _invoiceTitle = "فاتورة ضريبية / سند تسليم خدمات";
    [ObservableProperty] private string _invoiceSubtitle = "استديو الفن 3 للإنتاج الإعلامي والطباعة";
    [ObservableProperty] private string _invoiceFooterNote = "نشكركم لاختيار استديو الفن 3. نسعد دائماً بتخليد أجمل لحظاتكم.";
    [ObservableProperty] private string _receiptFooter = "سند رسمي صادر ومعتمد من إدارة استديو الفن 3.";
    [ObservableProperty] private string _invoiceTerms = "1. تسليم الأعمال خلال الموعد.\n2. التعديلات المتاحة مرتين كحد أقصى.\n3. يحفظ الأرشيف 60 يوماً.";

    // Users & Permissions Properties
    [ObservableProperty] private ObservableCollection<UserDto> _usersList = new();
    [ObservableProperty] private UserDto? _selectedUser;
    [ObservableProperty] private ObservableCollection<PermissionCheckItem> _permissionsList = new();

    // Password & Status
    [ObservableProperty] private string _currentPassword = string.Empty;
    [ObservableProperty] private string _newPassword = string.Empty;
    [ObservableProperty] private string _statusMessage = string.Empty;

    public SettingsViewModel(IStudioSettingsService settingsService, IBackupService backupService, IAuthService auth, ICurrentUserService currentUser)
    {
        _settingsService = settingsService;
        _backupService = backupService;
        _auth = auth;
        _currentUser = currentUser;

        InitializePermissionsMasterList();
        LoadSettingsCommand.Execute(null);
        LoadUsersCommand.Execute(null);
    }

    private void InitializePermissionsMasterList()
    {
        var master = new List<PermissionCheckItem>
        {
            new() { Key = "Dashboard:View", Module = "لوحة التحكم", Description = "مشاهدة لوحة التحكم والإحصائيات" },
            new() { Key = "Orders:View", Module = "الطلبات", Description = "مشاهدة سجل الطلبات والفواتير" },
            new() { Key = "Orders:Create", Module = "الطلبات", Description = "إضافة طلب جديد" },
            new() { Key = "Orders:Edit", Module = "الطلبات", Description = "تعديل بيانات وحالة الطلبات" },
            new() { Key = "Orders:Delete", Module = "الطلبات", Description = "حذف وإلغاء الطلبات" },
            new() { Key = "Customers:View", Module = "العملاء", Description = "مشاهدة قائمة العملاء" },
            new() { Key = "Customers:Create", Module = "العملاء", Description = "إضافة وتعديل بيانات العملاء" },
            new() { Key = "Customers:Delete", Module = "العملاء", Description = "حذف العملاء" },
            new() { Key = "Invoices:Create", Module = "الفواتير", Description = "إنشاء وإصدار الفواتير" },
            new() { Key = "Invoices:Print", Module = "الفواتير", Description = "طباعة الفواتير" },
            new() { Key = "Invoices:Reprint", Module = "الفواتير", Description = "إعادة طباعة الفواتير السابقة" },
            new() { Key = "Invoices:Delete", Module = "الفواتير", Description = "حذف وإلغاء الفواتير" },
            new() { Key = "Payments:Create", Module = "المدفوعات", Description = "تسجيل دفعات نقدية وبنكية ومحافظ" },
            new() { Key = "Payments:View", Module = "المدفوعات", Description = "مشاهدة سجل المقبوضات والدفعات" },
            new() { Key = "Payments:Delete", Module = "المدفوعات", Description = "حذف السندات والدفعات" },
            new() { Key = "Accounting:View", Module = "الحسابات", Description = "مشاهدة الحسابات والصندوق وحركة المال" },
            new() { Key = "Accounting:Edit", Module = "الحسابات", Description = "تعديل العمليات المالية" },
            new() { Key = "Accounting:Delete", Module = "الحسابات", Description = "حذف قيود وسندات الصندوق" },
            new() { Key = "Expenses:Create", Module = "المصروفات", Description = "إضافة سندات الصرف والمصروفات" },
            new() { Key = "Expenses:Edit", Module = "المصروفات", Description = "تعديل المصروفات" },
            new() { Key = "Expenses:Delete", Module = "المصروفات", Description = "حذف المصروفات" },
            new() { Key = "Salaries:View", Module = "الرواتب", Description = "مشاهدة الرواتب وسندات السلف" },
            new() { Key = "Salaries:Edit", Module = "الرواتب", Description = "صرف الرواتب واعتماد السلف" },
            new() { Key = "Reports:Sales", Module = "التقارير", Description = "مشاهدة تقرير المبيعات اليومية" },
            new() { Key = "Reports:TodayIncome", Module = "التقارير", Description = "مشاهدة تقرير دخل اليوم" },
            new() { Key = "Reports:CashierIncome", Module = "التقارير", Description = "مشاهدة تقرير دخل كل كاشير بالتفصيل" },
            new() { Key = "Reports:FullFinancial", Module = "التقارير", Description = "مشاهدة التقارير المالية الكاملة والأرباح" },
            new() { Key = "Settings:System", Module = "الإعدادات", Description = "تعديل إعدادات وبيانات النظام" },
            new() { Key = "Settings:StudioInfo", Module = "الإعدادات", Description = "تعديل بيانات الاستديو والشعار" },
            new() { Key = "Settings:Users", Module = "الإعدادات", Description = "إدارة المستخدمين ومنح الصلاحيات" },
            new() { Key = "Backup:Manage", Module = "النسخ الاحتياطي", Description = "إجراء واسترجاع النسخ الاحتياطية" }
        };
        PermissionsList = new ObservableCollection<PermissionCheckItem>(master);
    }

    [RelayCommand]
    private async Task LoadSettingsAsync()
    {
        var s = await _settingsService.GetSettingsAsync();
        StudioName = s.StudioName;
        SystemManagerName = s.SystemManagerName;
        Tagline = s.Tagline;
        Address = s.Address;
        Phone = s.Phone;
        SecondaryPhone = s.SecondaryPhone ?? "";
        Whatsapp = s.Whatsapp;
        Email = s.Email;
        Description = s.Description ?? "";
        Currency = s.Currency;
        LogoPath = s.LogoPath;
        LogoBase64 = s.LogoBase64;
        InvoiceTitle = s.InvoiceTitle;
        InvoiceSubtitle = s.InvoiceSubtitle;
        InvoiceFooterNote = s.InvoiceFooterNote;
        ReceiptFooter = s.ReceiptFooter;
        InvoiceTerms = s.InvoiceTerms;
        StatusMessage = "تم تحميل بيانات الاستديو بنجاح.";
    }

    [RelayCommand]
    private async Task SaveSettingsAsync()
    {
        var dto = new StudioSettingsDto(
            StudioName,
            SystemManagerName,
            Tagline,
            Address,
            Phone,
            SecondaryPhone,
            Whatsapp,
            Email,
            Description,
            null,
            Currency,
            LogoPath,
            LogoBase64,
            InvoiceTitle,
            InvoiceSubtitle,
            InvoiceFooterNote,
            ReceiptFooter,
            InvoiceTerms,
            "A4"
        );

        await _settingsService.UpdateSettingsAsync(dto);
        StatusMessage = "✓ تم حفظ وتحديث بيانات الاستديو واسم مدير النظام بنجاح!";
        MessageBox.Show("تم حفظ بيانات الاستديو واسم المدير بنجاح. تنعكس التغييرات تلقائياً في جميع الشاشات والمستندات.", "تم الحفظ", MessageBoxButton.OK, MessageBoxImage.Information, MessageBoxResult.OK, MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading);
    }

    [RelayCommand]
    private async Task CancelSettingsAsync()
    {
        await LoadSettingsAsync();
        StatusMessage = "تم إلغاء التعديلات واستعادة البيانات الأصلية.";
    }

    [RelayCommand]
    private void UploadLogo()
    {
        var dlg = new OpenFileDialog
        {
            Filter = "ملفات الصور|*.png;*.jpg;*.jpeg;*.bmp;*.webp",
            Title = "اختر شعار/صورة الاستديو"
        };
        if (dlg.ShowDialog() == true)
        {
            try
            {
                var bytes = File.ReadAllBytes(dlg.FileName);
                LogoBase64 = $"data:image/png;base64,{Convert.ToBase64String(bytes)}";
                LogoPath = dlg.FileName;
                StatusMessage = "✓ تم تحميل صورة الشعار بنجاح! اضغط [حفظ] لتثبيت التغيير.";
            }
            catch (Exception ex)
            {
                StatusMessage = $"خطأ في قراءة الصورة: {ex.Message}";
            }
        }
    }

    [RelayCommand]
    private void DeleteLogo()
    {
        LogoPath = null;
        LogoBase64 = null;
        StatusMessage = "تم إزالة الشعار. اضغط [حفظ] لتطبيق التغيير.";
    }

    [RelayCommand]
    private void PreviewLogo()
    {
        if (!string.IsNullOrWhiteSpace(LogoPath) && File.Exists(LogoPath))
        {
            Process.Start(new ProcessStartInfo(LogoPath) { UseShellExecute = true });
        }
        else
        {
            MessageBox.Show("لا يوجد مسار صورة متاح للمعاينة الخارجية.", "معاينة", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    [RelayCommand]
    private async Task LoadUsersAsync()
    {
        var users = await _auth.GetAllUsersAsync();
        UsersList = new ObservableCollection<UserDto>(users);
        if (UsersList.Count > 0)
        {
            SelectedUser = UsersList.FirstOrDefault(u => u.RoleName == "كاشير ومبيعات") ?? UsersList[0];
            OnSelectedUserChanged(SelectedUser);
        }
    }

    partial void OnSelectedUserChanged(UserDto? value)
    {
        if (value == null) return;

        foreach (var p in PermissionsList)
        {
            if (value.RoleName == "مدير النظام" || value.PermissionKeys.Contains("all"))
            {
                p.IsSelected = true;
            }
            else
            {
                p.IsSelected = value.PermissionKeys.Contains(p.Key);
            }
        }
    }

    [RelayCommand]
    private async Task AuthorizeUserAsync()
    {
        if (SelectedUser == null)
        {
            MessageBox.Show("يرجى اختيار المستخدم أولاً لتخويل صلاحياته.", "تنبيه", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var selectedKeys = PermissionsList.Where(p => p.IsSelected).Select(p => p.Key).ToList();
        var ok = await _auth.AuthorizeUserPermissionsAsync(SelectedUser.Id, selectedKeys, SelectedUser.IsActive);

        if (ok)
        {
            StatusMessage = $"🔐 تم تخويل وحفظ صلاحيات المستخدم [{SelectedUser.FullName}] بنجاح ({selectedKeys.Count} صلاحية مفعلة)!";
            MessageBox.Show(
                $"تم بنجاح تخويل الصلاحيات للمستخدم: {SelectedUser.FullName}\nتم تفعيل {selectedKeys.Count} صلاحية وربطها بالحساب فعلياً.",
                "🔐 تم التخويل بنجاح",
                MessageBoxButton.OK,
                MessageBoxImage.Information,
                MessageBoxResult.OK,
                MessageBoxOptions.RightAlign | MessageBoxOptions.RtlReading
            );
            await LoadUsersAsync();
        }
        else
        {
            StatusMessage = "فشل في حفظ الصلاحيات.";
        }
    }

    [RelayCommand]
    private void SelectAllPermissions()
    {
        foreach (var p in PermissionsList) p.IsSelected = true;
    }

    [RelayCommand]
    private void ClearAllPermissions()
    {
        foreach (var p in PermissionsList) p.IsSelected = false;
    }

    [RelayCommand]
    private async Task ChangePasswordAsync()
    {
        if (_currentUser.CurrentUser == null) return;
        var ok = await _auth.ChangePasswordAsync(_currentUser.CurrentUser.Id, CurrentPassword, NewPassword);
        StatusMessage = ok ? "تم تغيير كلمة المرور بنجاح." : "كلمة المرور الحالية غير صحيحة.";
    }

    [RelayCommand]
    private async Task CreateBackupAsync()
    {
        try
        {
            var folder = "C:\\StudioBackups";
            Directory.CreateDirectory(folder);
            var file = await _backupService.CreateBackupAsync(folder);
            StatusMessage = $"تم إنشاء النسخة الاحتياطية بنجاح: {file}";
        }
        catch (Exception ex)
        {
            StatusMessage = $"خطأ في النسخ: {ex.Message}";
        }
    }
}
