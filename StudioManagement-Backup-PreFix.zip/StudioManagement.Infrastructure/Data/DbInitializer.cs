using Microsoft.EntityFrameworkCore;
using StudioManagement.Domain.Entities;
using StudioManagement.Domain.Enums;

namespace StudioManagement.Infrastructure.Data;

public static class DbInitializer
{
    public static async Task SeedAsync(StudioDbContext context)
    {
        await context.Database.EnsureCreatedAsync();

        if (!await context.Users.AnyAsync())
        {
            var adminRole = new Role { Name = "مدير النظام", Description = "صلاحيات إدارية وفنية ومالية كاملة" };
            var cashierRole = new Role { Name = "كاشير ومبيعات", Description = "إدخال العملاء، الطلبات، والتحصيل المالي" };
            context.Roles.AddRange(adminRole, cashierRole);
            await context.SaveChangesAsync();

            // Seed Permissions
            var permissionsList = new List<Permission>
            {
                new() { Key = "Dashboard:View", Module = "لوحة التحكم", Description = "مشاهدة Dashboard" },
                new() { Key = "Orders:View", Module = "الطلبات", Description = "مشاهدة الطلبات" },
                new() { Key = "Orders:Create", Module = "الطلبات", Description = "إضافة طلب جديد" },
                new() { Key = "Orders:Edit", Module = "الطلبات", Description = "تعديل الطلبات" },
                new() { Key = "Orders:Delete", Module = "الطلبات", Description = "حذف الطلبات" },
                new() { Key = "Customers:View", Module = "العملاء", Description = "مشاهدة العملاء" },
                new() { Key = "Customers:Create", Module = "العملاء", Description = "إضافة عميل" },
                new() { Key = "Customers:Delete", Module = "العملاء", Description = "حذف عميل" },
                new() { Key = "Invoices:Create", Module = "الفواتير", Description = "إنشاء فاتورة" },
                new() { Key = "Invoices:Print", Module = "الفواتير", Description = "طباعة الفواتير" },
                new() { Key = "Invoices:Reprint", Module = "الفواتير", Description = "إعادة طباعة الفواتير" },
                new() { Key = "Invoices:Delete", Module = "الفواتير", Description = "حذف الفواتير" },
                new() { Key = "Payments:Create", Module = "المدفوعات", Description = "تسجيل دفعة" },
                new() { Key = "Payments:View", Module = "المدفوعات", Description = "مشاهدة المدفوعات" },
                new() { Key = "Payments:Delete", Module = "المدفوعات", Description = "حذف المدفوعات" },
                new() { Key = "Accounting:View", Module = "الحسابات", Description = "مشاهدة الحسابات والصندوق" },
                new() { Key = "Accounting:Edit", Module = "الحسابات", Description = "تعديل الحسابات" },
                new() { Key = "Accounting:Delete", Module = "الحسابات", Description = "حذف الحسابات" },
                new() { Key = "Expenses:Create", Module = "المصروفات", Description = "إضافة مصروف" },
                new() { Key = "Expenses:Edit", Module = "المصروفات", Description = "تعديل المصروفات" },
                new() { Key = "Expenses:Delete", Module = "المصروفات", Description = "حذف المصروفات" },
                new() { Key = "Salaries:View", Module = "الرواتب", Description = "مشاهدة الرواتب والسلف" },
                new() { Key = "Salaries:Edit", Module = "الرواتب", Description = "تعديل الرواتب والسلف" },
                new() { Key = "Reports:Sales", Module = "التقارير", Description = "تقرير المبيعات" },
                new() { Key = "Reports:TodayIncome", Module = "التقارير", Description = "تقرير دخل اليوم" },
                new() { Key = "Reports:FullFinancial", Module = "التقارير", Description = "التقارير المالية الكاملة" },
                new() { Key = "Reports:CashierIncome", Module = "التقارير", Description = "تقرير دخل الكاشير" },
                new() { Key = "Settings:System", Module = "الإعدادات", Description = "إعدادات النظام" },
                new() { Key = "Settings:StudioInfo", Module = "الإعدادات", Description = "بيانات الاستديو" },
                new() { Key = "Settings:Users", Module = "الإعدادات", Description = "المستخدمون والصلاحيات" },
                new() { Key = "Backup:Manage", Module = "النسخ الاحتياطي", Description = "إدارة النسخ الاحتياطي والاستعادة" }
            };
            context.Permissions.AddRange(permissionsList);
            await context.SaveChangesAsync();

            // Grant Admin all permissions
            foreach (var perm in permissionsList)
            {
                context.RolePermissions.Add(new RolePermission { RoleId = adminRole.Id, PermissionId = perm.Id });
            }

            // Grant Cashier specific default permissions
            var cashierDefaultKeys = new[] { "Dashboard:View", "Orders:View", "Orders:Create", "Orders:Edit", "Customers:View", "Customers:Create", "Invoices:Create", "Invoices:Print", "Invoices:Reprint", "Payments:Create", "Payments:View", "Reports:Sales", "Reports:TodayIncome" };
            foreach (var perm in permissionsList.Where(p => cashierDefaultKeys.Contains(p.Key)))
            {
                context.RolePermissions.Add(new RolePermission { RoleId = cashierRole.Id, PermissionId = perm.Id });
            }
            await context.SaveChangesAsync();

            var adminUser = new User
            {
                UserNumber = 1001,
                Username = "admin",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("123456"),
                FullName = "المهندس زكريا فيصل العزعزي",
                Phone = "777000111",
                IsActive = true
            };

            var cashierUser = new User
            {
                UserNumber = 1002,
                Username = "cashier",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("123456"),
                FullName = "أحمد عبد الله المحمدي",
                Phone = "777111222",
                IsActive = true
            };

            context.Users.AddRange(adminUser, cashierUser);
            await context.SaveChangesAsync();

            context.UserRoles.AddRange(
                new UserRole { UserId = adminUser.Id, RoleId = adminRole.Id },
                new UserRole { UserId = cashierUser.Id, RoleId = cashierRole.Id }
            );

            // Seed Studio Settings
            context.StudioSettings.Add(new StudioSettings());

            // Seed Default Product Category
            var cat = new ProductCategory { Name = "عام", Description = "خامات ومستلزمات استديو عامة" };
            context.ProductCategories.Add(cat);
            await context.SaveChangesAsync();

            // Seed Default Products
            context.Products.AddRange(
                new Product { Code = "PRD-001", Name = "ورق كوداك فوتوغرافي لماع A4", CategoryId = cat.Id, CurrentQuantity = 50, MinimumQuantity = 10, CostPrice = 6500, SellingPrice = 12000, Unit = "باكت" },
                new Product { Code = "PRD-002", Name = "طقم أحبار كانون وإبسون 6 ألوان", CategoryId = cat.Id, CurrentQuantity = 8, MinimumQuantity = 3, CostPrice = 42000, SellingPrice = 70000, Unit = "طقم" },
                new Product { Code = "PRD-003", Name = "ألواح أكريليك شفاف 80×120 سم", CategoryId = cat.Id, CurrentQuantity = 15, MinimumQuantity = 5, CostPrice = 18000, SellingPrice = 35000, Unit = "لوح" },
                new Product { Code = "PRD-004", Name = "أكواب سحرية سبلميشن", CategoryId = cat.Id, CurrentQuantity = 24, MinimumQuantity = 6, CostPrice = 1200, SellingPrice = 3000, Unit = "حبة" }
            );

            // Seed Default 12 Studio Services (3x4 Grid)
            var services = new List<StudioService>
            {
                new() { ServiceType = ServiceType.WeddingBoard, Name = "لوحات العرسان الفاخرة", Description = "تصميم وطباعة اللوحات الملكية الكبيرة بإطارات خشبية وإضاءة LED", Icon = "Palette", DisplayOrder = 1, DefaultPrice = 95000 },
                new() { ServiceType = ServiceType.WeddingSession, Name = "جلسات تصوير عرسان VIP", Description = "تصوير احترافي مخصص للعرسان داخل الاستديو الملكي", Icon = "Sparkles", DisplayOrder = 2, DefaultPrice = 110000 },
                new() { ServiceType = ServiceType.StudioPhotos, Name = "الصور وجلسات الاستديو", Description = "جلسات بورتريه شخصية، عائلية، تخرج، وصور رسمية", Icon = "Camera", DisplayOrder = 3, DefaultPrice = 45000 },
                new() { ServiceType = ServiceType.PhotoAlbums, Name = "ألبومات الصور الفاخرة", Description = "ألبومات زفاف ديجيتال حرارية جلد إيطالي وأكريليك", Icon = "BookOpen", DisplayOrder = 4, DefaultPrice = 120000 },
                new() { ServiceType = ServiceType.Advertising, Name = "الدعاية والإعلان والبنرات", Description = "طباعة بنرات فليكس، فينيل، ستيكرات، ورول اب", Icon = "Megaphone", DisplayOrder = 5, DefaultPrice = 75000 },
                new() { ServiceType = ServiceType.GraphicDesign, Name = "التصميمات والشعارات", Description = "هويات تجارية، كروت، بروشورات، وبطاقات دعوات رقمية", Icon = "PenTool", DisplayOrder = 6, DefaultPrice = 35000 },
                new() { ServiceType = ServiceType.PassportPhotos, Name = "صور الجوازات والمعاملات", Description = "تصوير فوري رسمي للجوازات والسفارات والمعاملات", Icon = "ShieldCheck", DisplayOrder = 7, DefaultPrice = 10000 },
                new() { ServiceType = ServiceType.PhotoRestoration, Name = "ترميم وتلوين الصور", Description = "معالجة وترميم الصور التالفة والقديمة بجودة فائقة", Icon = "Sparkles", DisplayOrder = 8, DefaultPrice = 30000 },
                new() { ServiceType = ServiceType.CanvasPrints, Name = "لوحات الكانفس الفنية", Description = "طباعة كانفس فاخرة مشدودة على خشب سويدي أصلي", Icon = "Palette", DisplayOrder = 9, DefaultPrice = 65000 },
                new() { ServiceType = ServiceType.VideoMontage, Name = "الفيديو والمونتاج السينمائي", Description = "تصوير سينمائي 4K، تصوير درون جوي ومونتاج تيزرات", Icon = "Film", DisplayOrder = 10, DefaultPrice = 150000 },
                new() { ServiceType = ServiceType.OutdoorPhoto, Name = "التصوير الخارجي والمناسبات", Description = "جلسات تصوير في حدائق ومنتجعات وتغطية الأفراح", Icon = "Image", DisplayOrder = 11, DefaultPrice = 85000 },
                new() { ServiceType = ServiceType.ThermalPrint, Name = "الطباعة الحرارية والهدايا", Description = "طباعة سبلميشن للتيشيرتات والأكواب والدروع التذكارية", Icon = "Flame", DisplayOrder = 12, DefaultPrice = 25000 }
            };
            context.StudioServices.AddRange(services);

            // Seed Initial Customer
            var cust = new Customer
            {
                CustomerNumber = "C-000001",
                Name = "عمار ياسين الشميري",
                Phone = "771234567",
                Address = "صنعاء - حي الأصبحي",
                Notes = "عميل مميز - حفل زفاف"
            };
            context.Customers.Add(cust);
            await context.SaveChangesAsync();

            // Seed Initial Order
            var order = new Order
            {
                OrderNumber = "ORD-2026-000001",
                CustomerId = cust.Id,
                ServiceType = ServiceType.WeddingBoard,
                ServiceTitle = "لوحات العرسان الفاخرة",
                Subtotal = 110000,
                Discount = 5000,
                TotalAmount = 105000,
                PaidAmount = 70000,
                RemainingAmount = 35000,
                Status = OrderStatus.InPrinting,
                OrderDate = DateTime.Now.AddDays(-5),
                DeliveryDate = DateTime.Now.AddDays(3),
                DeliveryTime = "06:00 م",
                CreatedByUserId = adminUser.Id,
                Notes = "لوحة ملكية 80×120 سم مع إضاءة دافئة LED"
            };
            order.Items.Add(new OrderItem
            {
                ServiceType = ServiceType.WeddingBoard,
                Title = "لوحة عرسان ملكية فاخرة مقاس 80×120 سم إضاءة LED",
                Quantity = 1,
                UnitPrice = 110000,
                TotalPrice = 110000
            });
            order.Payments.Add(new Payment
            {
                Amount = 70000,
                Method = PaymentMethod.BankWallet,
                WalletType = WalletType.Kuraimi,
                WalletName = "كريمي / إم فلوس",
                TransactionNumber = "TX-9988231",
                ReceivedByUserId = cashierUser.Id,
                Notes = "دفعة أولى عند توقيع الطلب"
            });
            context.Orders.Add(order);

            await context.SaveChangesAsync();
        }
    }
}
