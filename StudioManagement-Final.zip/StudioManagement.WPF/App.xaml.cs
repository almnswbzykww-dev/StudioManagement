using System.Windows;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using StudioManagement.Application.Interfaces;
using StudioManagement.Infrastructure.Data;
using StudioManagement.Infrastructure.Services;
using StudioManagement.Reports;
using StudioManagement.WPF.ViewModels;
using StudioManagement.WPF.Views;

namespace StudioManagement.WPF;

public partial class App : System.Windows.Application
{
    private IHost? _host;

    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        _host = Host.CreateDefaultBuilder()
            .ConfigureServices((context, services) =>
            {
                var providerMode = context.Configuration["DatabaseProvider"] ?? "Auto";
                var sqlServerConn = context.Configuration.GetConnectionString("StudioDb") 
                    ?? "Server=.\\SQLEXPRESS;Database=StudioManagementDb;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=true;Connect Timeout=3;";
                var sqliteConn = context.Configuration.GetConnectionString("SqliteDb") 
                    ?? "Data Source=StudioManagement.db";

                bool useSqlServer = false;
                if (providerMode.Equals("SqlServer", StringComparison.OrdinalIgnoreCase))
                {
                    useSqlServer = true;
                }
                else if (providerMode.Equals("Sqlite", StringComparison.OrdinalIgnoreCase))
                {
                    useSqlServer = false;
                }
                else
                {
                    // Auto: Test if SQL Server is responsive in 2 seconds; if not, use offline SQLite
                    try
                    {
                        using var testConn = new Microsoft.Data.SqlClient.SqlConnection(sqlServerConn);
                        testConn.Open();
                        useSqlServer = true;
                    }
                    catch
                    {
                        useSqlServer = false;
                    }
                }

                services.AddDbContext<StudioDbContext>(options =>
                {
                    if (useSqlServer)
                    {
                        options.UseSqlServer(sqlServerConn);
                    }
                    else
                    {
                        options.UseSqlite(sqliteConn);
                    }
                });

                // Application Services
                services.AddSingleton<ICurrentUserService, CurrentUserService>();
                services.AddScoped<IAuthService, AuthService>();
                services.AddScoped<INumberGeneratorService, NumberGeneratorService>();
                services.AddScoped<ICustomerService, CustomerService>();
                services.AddScoped<IOrderService, OrderService>();
                services.AddScoped<IInventoryService, InventoryService>();
                services.AddScoped<IPurchaseService, PurchaseService>();
                services.AddScoped<IExpenseService, ExpenseService>();
                services.AddScoped<IAccountingService, AccountingService>();
                services.AddScoped<IEmployeeService, EmployeeService>();
                services.AddScoped<IPayrollService, PayrollService>();
                services.AddScoped<IStudioSettingsService, StudioSettingsService>();
                services.AddScoped<IServiceCardService, ServiceCardService>();
                services.AddScoped<IAuditLogService, AuditLogService>();
                services.AddScoped<IBackupService, BackupService>();
                services.AddScoped<INotificationService, NotificationService>();
                services.AddScoped<IPrintService, PrintService>();

                // Reports
                services.AddScoped<IInvoiceHtmlBuilder, InvoiceHtmlBuilder>();
                services.AddScoped<IReportHtmlBuilder, ReportHtmlBuilder>();
                services.AddScoped<IExcelExportService, ExcelExportService>();

                // ViewModels
                services.AddSingleton<MainViewModel>();
                services.AddTransient<LoginViewModel>();
                services.AddTransient<DashboardViewModel>();
                services.AddTransient<CustomersViewModel>();
                services.AddTransient<OrdersViewModel>();
                services.AddTransient<OrderWizardViewModel>();
                services.AddTransient<InventoryViewModel>();
                services.AddTransient<PurchaseFormViewModel>();
                services.AddTransient<SuppliersViewModel>();
                services.AddTransient<AccountingViewModel>();
                services.AddTransient<ReportsViewModel>();
                services.AddTransient<SettingsViewModel>();
                services.AddTransient<PrintPreviewViewModel>();

                // Views
                services.AddTransient<MainWindow>();
                services.AddTransient<LoginWindow>();
                services.AddTransient<PrintPreviewWindow>();
            })
            .Build();

        await _host.StartAsync();

        // Ensure database is seeded
        using (var scope = _host.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<StudioDbContext>();
            try
            {
                await DbInitializer.SeedAsync(db);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Database seeding exception: {ex.Message}");
            }
        }

        // Show Login
        var loginWindow = _host.Services.GetRequiredService<LoginWindow>();
        loginWindow.Show();
    }

    protected override async void OnExit(ExitEventArgs e)
    {
        if (_host != null)
        {
            await _host.StopAsync();
            _host.Dispose();
        }
        base.OnExit(e);
    }
}
