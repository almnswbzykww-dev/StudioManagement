using System.Windows;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using StudioManagement.Application.Interfaces;
using StudioManagement.Infrastructure.Data;
using StudioManagement.Infrastructure.Services;
using StudioManagement.Reports;
using StudioManagement.WPF.ViewModels;
using StudioManagement.WPF.Views;

namespace StudioManagement.WPF;

public partial class App : System.Windows.Application
{
    private IHost? _host;

    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        _host = Host.CreateDefaultBuilder()
            .ConfigureServices((context, services) =>
            {
                var connStr = context.Configuration.GetConnectionString("StudioDb") 
                    ?? "Server=.\\SQLEXPRESS;Database=StudioManagementDb;Trusted_Connection=True;TrustServerCertificate=True;";

                services.AddDbContext<StudioDbContext>(options =>
                    options.UseSqlServer(connStr));

                // Application Services
                services.AddSingleton<ICurrentUserService, CurrentUserService>();
                services.AddScoped<IAuthService, AuthService>();
                services.AddScoped<INumberGeneratorService, NumberGeneratorService>();
                services.AddScoped<ICustomerService, CustomerService>();
                services.AddScoped<IOrderService, OrderService>();
                services.AddScoped<IInventoryService, InventoryService>();
                services.AddScoped<IPurchaseService, PurchaseService>();
                services.AddScoped<IExpenseService, ExpenseService>();
                services.AddScoped<IAccountingService, AccountingService>();
                services.AddScoped<IEmployeeService, EmployeeService>();
                services.AddScoped<IPayrollService, PayrollService>();
                services.AddScoped<IStudioSettingsService, StudioSettingsService>();
                services.AddScoped<IServiceCardService, ServiceCardService>();
                services.AddScoped<IAuditLogService, AuditLogService>();
                services.AddScoped<IBackupService, BackupService>();

                // Reports
                services.AddScoped<IInvoiceHtmlBuilder, InvoiceHtmlBuilder>();
                services.AddScoped<IReportHtmlBuilder, ReportHtmlBuilder>();
                services.AddScoped<IExcelExportService, ExcelExportService>();

                // ViewModels
                services.AddSingleton<MainViewModel>();
                services.AddTransient<LoginViewModel>();
                services.AddTransient<DashboardViewModel>();
                services.AddTransient<CustomersViewModel>();
                services.AddTransient<OrdersViewModel>();
                services.AddTransient<OrderWizardViewModel>();
                services.AddTransient<InventoryViewModel>();
                services.AddTransient<PurchaseFormViewModel>();
                services.AddTransient<SuppliersViewModel>();
                services.AddTransient<AccountingViewModel>();
                services.AddTransient<ReportsViewModel>();
                services.AddTransient<SettingsViewModel>();

                // Views
                services.AddTransient<MainWindow>();
                services.AddTransient<LoginWindow>();
            })
            .Build();

        await _host.StartAsync();

        // Ensure database is seeded
        using (var scope = _host.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<StudioDbContext>();
            await DbInitializer.SeedAsync(db);
        }

        // Show Login
        var loginWindow = _host.Services.GetRequiredService<LoginWindow>();
        loginWindow.Show();
    }

    protected override async void OnExit(ExitEventArgs e)
    {
        if (_host != null)
        {
            await _host.StopAsync();
            _host.Dispose();
        }
        base.OnExit(e);
    }
}
